const productos = [
  { id: 1, nombre: "Arroz 1kg", precio: 2.5, imagen: "https://via.placeholder.com/150" },
  { id: 2, nombre: "Azúcar 1kg", precio: 2.0, imagen: "https://via.placeholder.com/150" },
  { id: 3, nombre: "Aceite 1L", precio: 4.0, imagen: "https://via.placeholder.com/150" },
];